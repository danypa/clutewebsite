<ul class="subsubsub">
  <?php do_action('wooccm_sections_header'); ?>
  <li><a target="_blank" href="<?php echo WOOCCM_DOCUMENTATION_URL; ?>"><?php echo esc_html__('Documentation', 'woocommerce-checkout-manager'); ?></a></li> | 
  <li><a href="<?php echo admin_url('admin.php?page=' . WOOCCM_PREFIX); ?>"><?php echo esc_html__('Premium', 'woocommerce-checkout-manager'); ?></a></li>
</ul>
<br class="clear" />